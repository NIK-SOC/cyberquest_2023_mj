const t=""+new URL("../assets/witch4.41e54c11.png",import.meta.url).href;export{t as default};
