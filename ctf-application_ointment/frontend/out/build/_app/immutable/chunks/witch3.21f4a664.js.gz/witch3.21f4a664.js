const t=""+new URL("../assets/witch3.327b8bde.png",import.meta.url).href;export{t as default};
