const t=""+new URL("../assets/witch1.f2e2f32a.png",import.meta.url).href;export{t as default};
