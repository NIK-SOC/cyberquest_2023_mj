const t=""+new URL("../assets/witch2.4416bbfc.png",import.meta.url).href;export{t as default};
